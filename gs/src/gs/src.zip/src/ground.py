#!/usr/bin/env python

import matplotlib.pyplot as plt
import os

import numpy as np
import Tkinter as tk
import math


import rospy
from std_msgs.msg import String
import threading

# 17 Byte in total
#Byte 0,1 ----> message id
#Byte 2,3,4 ----> first uav
#Byte 5,6,7 ----> second uav
#Byte 8,9,10 ----> third uav
#Byte 11,12,13 ----> fourth uav
#Byte 14,15,16 ----> fifth uav

##define obtaincontrol = 0x80
##define takeoff = 0x40
##define land = 0x20
##define rtl = 0x10
##define reboot = 0x08


global message
message = np.array([0,0,0,0,0,0,0,0,0,0,0,0], dtype='uint8')


#t1=threading.Thread(target = gui, args=("t1",))
#t2=threading.Thread(target= run, args=("t2",))





def all_obtain_control_callback():
	global message
	message[2] = message[2] | 0x10
	message[4] = message[4] | 0x10
	message[6] = message[6] | 0x10
	message[8] = message[8] | 0x10
	message[10] = message[10] | 0x10
	
def all_takeoff_callback():
	global message
	message[2] = message[2] | 0x08
	message[4] = message[4] | 0x08
	message[6] = message[6] | 0x08
	message[8] = message[8] | 0x08
	message[10] = message[10] | 0x08
	
def all_land_callback():
	global message
	message[2] = message[2] | 0x02
	message[4] = message[4] | 0x02
	message[6] = message[6] | 0x02
	message[8] = message[8] | 0x02
	message[10] = message[10] | 0x02
	
def all_rtl_callback():
	global message
	message[2] = message[2] | 0x01
	message[4] = message[4] | 0x01
	message[6] = message[6] | 0x01
	message[8] = message[8] | 0x01
	message[10] = message[10] | 0x01
	
	
	
	
	
	
def reboot1():
	global message
	message[2] = message[2] | 0x04
def reboot2():
	global message
	message[4] = message[4] | 0x04
def reboot3():
	global message
	message[6] = message[6] | 0x04
def reboot4():
	global message
	message[8] = message[8] | 0x04
def reboot5():
	global message
	message[10] = message[10] | 0x04

def obtain_control1():
	global message
	message[2] = message[2] | 0x10
def obtain_control2():
	global message
	message[4] = message[4] | 0x10
def obtain_control3():
	global message
	message[6] = message[6] | 0x10
def obtain_control4():
	global message
	message[8] = message[8] | 0x10
def obtain_control5():
	global message
	message[10] = message[10] | 0x10
	
def takeoff1():
	global message
	message[2] = message[2] | 0x08
def takeoff2():
	global message
	message[4] = message[4] | 0x08
def takeoff3():
	global message
	message[6] = message[6] | 0x08
def takeoff4():
	global message
	message[8] = message[8] | 0x08
def takeoff5():
	global message
	message[10] = message[10] | 0x08
	
	
def gui():
	global message
	frame = tk.Tk()
	frame.title('Ground Station')
	img = tk.PhotoImage(file='hit2.png')
	
	
	w = img.width()
	h = img.height()
	frame.geometry('%dx%d+0+0' % (w,h))
	
	
	#	Label
	background_label = tk.Label(frame, 
															image = img).place(x=0, y=0, relwidth=1, relheight=1)
	
	top_label = tk.Label(frame, 
											 text="***************************   Welcome  to  HITCSC  Ground  Station   ***************************", 
											 width = 80, height = 2,
											 fg="red", bg = "DarkBlue",
											 font="Helvetica -23 bold").place(x=0,y=30)
											 
	bottom_label = tk.Label(frame, 
											 text="********* Honor  Industriousness  Transcension  Cooperation  Steadfastness  Champion *********", 
											 width = 80, height = 2,
											 fg="red", bg = "DarkBlue",
											 font="Helvetica -23 bold").place(x=0,y=610)
											 
	top_label = tk.Label(frame, 
											 text="Reboot : ", 
											 width = 18, height = 1,
											 fg="red", bg = "LemonChiffon",
											 font="Helvetica -20 bold").place(x=30,y=285)
											 
											 
	top_label = tk.Label(frame, 
											 text="Obtain  control : ", 
											 width = 18, height = 1,
											 fg="red", bg = "LemonChiffon",
											 font="Helvetica -20 bold").place(x=30,y=356)
											 
											 
	top_label = tk.Label(frame, 
											 text="Take  off : ", 
											 width = 18, height = 1,
											 fg="red", bg = "LemonChiffon",
											 font="Helvetica -20 bold").place(x=30,y=424)
											 
	
	
	#	Button
	tk.Button(frame, 
						text="All  obtain  control",
						fg="green", bg="LemonChiffon", 
						font="Helvetica -20 bold",
						width=50,height=1, 
						command=all_obtain_control_callback).place(x=30,y=150)
					

	tk.Button(frame, 
						text="All  take  off",
						fg="green", bg="LemonChiffon", 
						font="Helvetica -20 bold",
						width=50,height=1, 
						command=all_takeoff_callback).place(x=30,y=210)
						
	tk.Button(frame, 
						text="All  land",
						fg="green", bg="LemonChiffon", 
						font="Helvetica -20 bold",
						width=50,height=1, 
						command=all_land_callback).place(x=30,y=490)
						
	tk.Button(frame, 
						text="All  rtl",
						fg="green", bg="LemonChiffon", 
						font="Helvetica -20 bold",
						width=50,height=1, 
						command=all_rtl_callback).place(x=30,y=550)
						
						
						
						
						
						
						
	tk.Button(frame, 
						text="1",
						fg="green", bg="LemonChiffon", 
						font="Helvetica -20 bold",
						width=2,height=1, 
						command = reboot1).place(x=290,y=280)
	
	tk.Button(frame, 
						text="2",
						fg="green", bg="LemonChiffon", 
						font="Helvetica -20 bold",
						width=2,height=1, 
						command = reboot2).place(x=370,y=280)
						
	tk.Button(frame, 
						text="3",
						fg="green", bg="LemonChiffon", 
						font="Helvetica -20 bold",
						width=2,height=1, 
						command = reboot3).place(x=450,y=280)
						
	tk.Button(frame, 
						text="4",
						fg="green", bg="LemonChiffon", 
						font="Helvetica -20 bold",
						width=2,height=1, 
						command = reboot4).place(x=530,y=280)
						
	tk.Button(frame, 
						text="5",
						fg="SeaGreen", bg="LemonChiffon", 
						font="Helvetica -20 bold",
						width=2,height=1, 
						command = reboot5).place(x=610,y=280)
						
						
						
						
	
	
	tk.Button(frame, 
						text="1",
						fg="green", bg="LemonChiffon", 
						font="Helvetica -20 bold",
						width=2,height=1, 
						command = obtain_control1).place(x=290,y=350)
	
	tk.Button(frame, 
						text="2",
						fg="green", bg="LemonChiffon", 
						font="Helvetica -20 bold",
						width=2,height=1, 
						command = obtain_control2).place(x=370,y=350)
						
	tk.Button(frame, 
						text="3",
						fg="green", bg="LemonChiffon", 
						font="Helvetica -20 bold",
						width=2,height=1, 
						command = obtain_control3).place(x=450,y=350)
						
	tk.Button(frame, 
						text="4",
						fg="green", bg="LemonChiffon", 
						font="Helvetica -20 bold",
						width=2,height=1, 
						command = obtain_control4).place(x=530,y=350)
						
	tk.Button(frame, 
						text="5",
						fg="SeaGreen", bg="LemonChiffon", 
						font="Helvetica -20 bold",
						width=2,height=1, 
						command = obtain_control5).place(x=610,y=350)
						
						
						
						
						
	tk.Button(frame, 
						text="1",
						fg="green", bg="LemonChiffon", 
						font="Helvetica -20 bold",
						width=2,height=1, 
						command = takeoff1).place(x=290,y=420)
	
	tk.Button(frame, 
						text="2",
						fg="green", bg="LemonChiffon", 
						font="Helvetica -20 bold",
						width=2,height=1, 
						command = takeoff2).place(x=370,y=420)
						
	tk.Button(frame, 
						text="3",
						fg="green", bg="LemonChiffon", 
						font="Helvetica -20 bold",
						width=2,height=1, 
						command = takeoff3).place(x=450,y=420)
						
	tk.Button(frame, 
						text="4",
						fg="green", bg="LemonChiffon", 
						font="Helvetica -20 bold",
						width=2,height=1, 
						command = takeoff4).place(x=530,y=420)
						
	tk.Button(frame, 
						text="5",
						fg="SeaGreen", bg="LemonChiffon", 
						font="Helvetica -20 bold",
						width=2,height=1, 
						command = takeoff5).place(x=610,y=420)

	frame.mainloop()
	

	
t1 = threading.Thread(target = gui)
t1.start()

pub = rospy.Publisher('/station_cmd', String, queue_size=10)
rospy.init_node('station', anonymous=True)
rate = rospy.Rate(1) # 1hz
	

msgCnt = 0
station_str = "12345678901234567"
while not rospy.is_shutdown():
	msgCnt = msgCnt + 1
	message[0] = msgCnt % 256
	message[1] = (msgCnt / 256) % 256
	rospy.loginfo(message)
	station_str = message.tostring()
	pub.publish(station_str)
	message[2:12] =  np.array([0,0,0,0,0,0,0,0,0,0], dtype='uint8')
	rate.sleep()
